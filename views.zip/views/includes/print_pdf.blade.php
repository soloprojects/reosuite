

<a class="btn bg-red waves-effect pull-right" onClick ="print_content('{{$exportId}}');" ><i class="fa fa-print"></i>Print/PDF</a>

