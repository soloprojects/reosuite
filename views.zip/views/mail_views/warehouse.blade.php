
<p>
    {{$message}}
</p>