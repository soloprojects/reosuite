@extends('mail_views.mail_layout')

@section('content')

    {{$data['message']}}

@endsection