@extends('layouts.temp_app')

@section('content')

    @include('assump_constraint.page',['item'=>$item,'mainData'=>$mainData])

@endsection