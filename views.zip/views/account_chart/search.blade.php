
@include('account_chart.table',['mainData' => $mainData])
