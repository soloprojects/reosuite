

@include('bank_reconciliation.table',['mainData' => $mainData])
