@extends('layouts.app')

@section('content')

    @include('project.page_item',['item'=>$item])

@endsection