@extends('layouts.temp_app')

@section('content')

    @include('project.page_item',['item'=>$item])

@endsection