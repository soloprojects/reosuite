@extends('layouts.temp_app')

@section('content')
you are welcome

@endsection